﻿using Microsoft.AspNetCore.Mvc.Rendering;
using System.ComponentModel.DataAnnotations;

namespace Online_VisApp.ViewModels
{
    public class VisaApplicationViewModel
    {
       
            public int VisaCountry { get; set; }   // Selected country ID
            public int VisaType { get; set; }      // Selected visa type ID
            public int VisaDuration { get; set; }  // Selected visa duration ID

            public int CountryOfOrigin { get; set; }
            // These will hold the options for each dropdown
            public List<SelectListItem> VisaCountries { get; set; } = new List<SelectListItem>();
            public List<SelectListItem> VisaTypes { get; set; } = new List<SelectListItem>();
            public List<SelectListItem> VisaDurations { get; set; } = new List<SelectListItem>();

            public List<SelectListItem> CountryOfOrigins { get; set; } = new List<SelectListItem>();

            // Personal Details
            [Required(ErrorMessage = "Name is required.")]
            public string Name { get; set; }

            [Required(ErrorMessage = "Phone number is required.")]
            [Phone(ErrorMessage = "Enter a valid phone number.")]
            public string PhoneNumber { get; set; }

            [Required(ErrorMessage = "Email ID is required.")]
            [EmailAddress(ErrorMessage = "Enter a valid email address.")]
            public string EmailId { get; set; }

            [Required(ErrorMessage = "Date of Birth is required.")]
            [DataType(DataType.Date)]
            public DateTime DateOfBirth { get; set; }

            [Required(ErrorMessage = "Gender is required.")]
            public string Gender { get; set; }

            [Required(ErrorMessage = "Marital status is required.")]
            public string MaritalStatus { get; set; }

            public string FatherName { get; set; }
            public string MotherName { get; set; }

            // Address Details
            [Required(ErrorMessage = "Street address is required.")]
            public string StreetAddress { get; set; }

            [Required(ErrorMessage = "City is required.")]
            public string City { get; set; }

            [Required(ErrorMessage = "State is required.")]
            public string State { get; set; }

            [Required(ErrorMessage = "Zip Code is required.")]
            public string ZipCode { get; set; }

            // Passport Details
            [Required(ErrorMessage = "Passport number is required.")]
            public string PassportNumber { get; set; }

            [Required(ErrorMessage = "Place of issue is required.")]
            public string PlaceOfIssue { get; set; }

            [Required(ErrorMessage = "Date of issue is required.")]
            [DataType(DataType.Date)]
            public DateTime DateOfIssue { get; set; }

            [Required(ErrorMessage = "Passport expiry date is required.")]
            [DataType(DataType.Date)]
            public DateTime PassportExpiryDate { get; set; }

            // Travel Details
            [Required(ErrorMessage = "Travel from date is required.")]
            [DataType(DataType.Date)]
            public DateTime TravelFromDate { get; set; }

            [Required(ErrorMessage = "Travel to date is required.")]
            [DataType(DataType.Date)]
            public DateTime TravelToDate { get; set; }

            public string TravelComments { get; set; }

            // Document Uploads
            [Required(ErrorMessage = "Passport size photo is required.")]
            public IFormFile PassportPhoto { get; set; }

            [Required(ErrorMessage = "Passport front page is required.")]
            public IFormFile PassportFrontPage { get; set; }

            [Required(ErrorMessage = "Passport last page is required.")]
            public IFormFile PassportLastPage { get; set; }

            [Required(ErrorMessage = "Police clearance certificate is required.")]
            public IFormFile PoliceClearance { get; set; }

            [Required(ErrorMessage = "Travel Itinerary is required.")]
            public IFormFile TravelItinerary { get; set; }

            [Required(ErrorMessage = "Hotel Booking Proof is required.")]
            public IFormFile HotelBookingProof { get; set; }

            [Required(ErrorMessage = "Flight Ticket Copy is required.")]
            public IFormFile FlightTicketCopy { get; set; }

            [Required]
            public bool DeclarationAccepted { get; set; }
        }
    }
