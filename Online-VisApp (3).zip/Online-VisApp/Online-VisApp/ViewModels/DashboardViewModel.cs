﻿namespace Online_VisApp.ViewModels
{
    public class DashboardViewModel
    {
        public int ApplicationId { get; set; }
        public string FirstName { get; set; }
        public string PhoneNo { get; set; }
        public string EmailID { get; set; }
        public string VisaTypeName { get; set; }
        public string StatusName { get; set; }
        public string PassportPhotoBase64 { get; set; } // To store base64 encoded image

    }
}
