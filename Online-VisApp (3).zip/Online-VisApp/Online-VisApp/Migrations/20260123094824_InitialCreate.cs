﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Online_VisApp.Migrations
{
    /// <inheritdoc />
    public partial class InitialCreate : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "ApplicantUSer",
                columns: table => new
                {
                    UserID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    EmailID = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Phoneno = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Username = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Password = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Question1 = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Answer1 = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ApplicantUSer", x => x.UserID);
                });

            migrationBuilder.CreateTable(
                name: "CountryMaster",
                columns: table => new
                {
                    CountryID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    CountryType = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    CountryName = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_CountryMaster", x => x.CountryID);
                });

            migrationBuilder.CreateTable(
                name: "DocumentMaster",
                columns: table => new
                {
                    DocumentID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    DocumentName = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_DocumentMaster", x => x.DocumentID);
                });

            migrationBuilder.CreateTable(
                name: "StatusMaster",
                columns: table => new
                {
                    StatusID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    StatusCode = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    StatusName = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_StatusMaster", x => x.StatusID);
                });

            migrationBuilder.CreateTable(
                name: "VisaDurationMaster",
                columns: table => new
                {
                    VisaDurationID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    VisaDuration = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_VisaDurationMaster", x => x.VisaDurationID);
                });

            migrationBuilder.CreateTable(
                name: "VisaTypeMaster",
                columns: table => new
                {
                    VisaTypeID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    VisaTypeName = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_VisaTypeMaster", x => x.VisaTypeID);
                });

            migrationBuilder.CreateTable(
                name: "Application_GeneralDetails",
                columns: table => new
                {
                    ApplicationID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    FirstName = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    LastName = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    DOB = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    CountryofOrigin = table.Column<int>(type: "int", nullable: true),
                    Gender = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    MaritalStatus = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Occupation = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Phoneno = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    EmailID = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Address = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    City = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    State = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ZipCode = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    CountryID = table.Column<int>(type: "int", nullable: true),
                    VisaTypeID = table.Column<int>(type: "int", nullable: true),
                    VisaDurationID = table.Column<int>(type: "int", nullable: true),
                    VisaCountry = table.Column<int>(type: "int", nullable: true),
                    Applicantid = table.Column<int>(type: "int", nullable: true),
                    VisaStatus = table.Column<int>(type: "int", nullable: true),
                    FatherName = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    MotherName = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Application_GeneralDetails", x => x.ApplicationID);
                    table.ForeignKey(
                        name: "FK_Application_StatusMaster",
                        column: x => x.VisaStatus,
                        principalTable: "StatusMaster",
                        principalColumn: "StatusID",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_Application_VisaType",
                        column: x => x.VisaTypeID,
                        principalTable: "VisaTypeMaster",
                        principalColumn: "VisaTypeID",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "Application_DocumentDetails",
                columns: table => new
                {
                    ApplicationDocumentID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ApplicationID = table.Column<int>(type: "int", nullable: false),
                    DocumentType = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    DocumentID = table.Column<int>(type: "int", nullable: true),
                    Documenet = table.Column<byte[]>(type: "varbinary(max)", nullable: false),
                    ApplicationId = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Application_DocumentDetails", x => x.ApplicationDocumentID);
                    table.ForeignKey(
                        name: "FK_Application_DocumentDetails_Application_GeneralDetails_ApplicationId",
                        column: x => x.ApplicationId,
                        principalTable: "Application_GeneralDetails",
                        principalColumn: "ApplicationID",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Application_PassportDetails",
                columns: table => new
                {
                    ApplicationPassportID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ApplicationID = table.Column<int>(type: "int", nullable: false),
                    PassportNo = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Issuedat = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    IssuedOn = table.Column<DateTime>(type: "datetime2", nullable: false),
                    Expirydate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    ApplicationGeneralDetailsApplicationID = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Application_PassportDetails", x => x.ApplicationPassportID);
                    table.ForeignKey(
                        name: "FK_Application_PassportDetails_Application_GeneralDetails_ApplicationGeneralDetailsApplicationID",
                        column: x => x.ApplicationGeneralDetailsApplicationID,
                        principalTable: "Application_GeneralDetails",
                        principalColumn: "ApplicationID",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Application_TravelDetails",
                columns: table => new
                {
                    ApplicationTravelID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ApplicationID = table.Column<int>(type: "int", nullable: false),
                    DateOfArrival = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    TravelToDate = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Comments = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    ApplicationGeneralDetailsApplicationID = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Application_TravelDetails", x => x.ApplicationTravelID);
                    table.ForeignKey(
                        name: "FK_Application_TravelDetails_Application_GeneralDetails_ApplicationGeneralDetailsApplicationID",
                        column: x => x.ApplicationGeneralDetailsApplicationID,
                        principalTable: "Application_GeneralDetails",
                        principalColumn: "ApplicationID",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Application_DocumentDetails_ApplicationId",
                table: "Application_DocumentDetails",
                column: "ApplicationId");

            migrationBuilder.CreateIndex(
                name: "IX_Application_GeneralDetails_VisaStatus",
                table: "Application_GeneralDetails",
                column: "VisaStatus");

            migrationBuilder.CreateIndex(
                name: "IX_Application_GeneralDetails_VisaTypeID",
                table: "Application_GeneralDetails",
                column: "VisaTypeID");

            migrationBuilder.CreateIndex(
                name: "IX_Application_PassportDetails_ApplicationGeneralDetailsApplicationID",
                table: "Application_PassportDetails",
                column: "ApplicationGeneralDetailsApplicationID");

            migrationBuilder.CreateIndex(
                name: "IX_Application_TravelDetails_ApplicationGeneralDetailsApplicationID",
                table: "Application_TravelDetails",
                column: "ApplicationGeneralDetailsApplicationID");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "ApplicantUSer");

            migrationBuilder.DropTable(
                name: "Application_DocumentDetails");

            migrationBuilder.DropTable(
                name: "Application_PassportDetails");

            migrationBuilder.DropTable(
                name: "Application_TravelDetails");

            migrationBuilder.DropTable(
                name: "CountryMaster");

            migrationBuilder.DropTable(
                name: "DocumentMaster");

            migrationBuilder.DropTable(
                name: "VisaDurationMaster");

            migrationBuilder.DropTable(
                name: "Application_GeneralDetails");

            migrationBuilder.DropTable(
                name: "StatusMaster");

            migrationBuilder.DropTable(
                name: "VisaTypeMaster");
        }
    }
}
