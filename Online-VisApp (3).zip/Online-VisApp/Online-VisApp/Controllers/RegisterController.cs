﻿using Online_VisApp.Data;
using Online_VisApp.Models;
using Microsoft.AspNetCore.Mvc;
using Online_VisApp.Models;

namespace Online_VisApp.Controllers
{
    public class RegisterController : Controller
    {
        private readonly ApplicationDbContext _dbContext;
        public RegisterController(ApplicationDbContext context)
        {
            _dbContext = context;

        }
        public async Task<IActionResult> RegisterIndex()
        {
            return View();
        }

        [HttpPost]
        public IActionResult RegisterIndex(ApplicantUSer model)
        {
            if (ModelState.IsValid)
            {

                _dbContext.ApplicantUSer.Add(model);
                _dbContext.SaveChanges();
                return RedirectToAction("Index", "Login");
            }
            return View(model);
        }


    }
}

