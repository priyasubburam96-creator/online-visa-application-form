﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Online_VisApp.Data;

namespace Online_VisApp.Controllers
{
    public class LoginController : Controller
    {

        private readonly ApplicationDbContext _dbContext;
        public LoginController(ApplicationDbContext context)
        {
            _dbContext = context;
        }
        public IActionResult Index()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Index(string UserName, string Password)
        {
            var user = _dbContext.ApplicantUSer
                               .FirstOrDefault(u => u.Username == UserName && u.Password == Password);

            if (user != null)
            {
                HttpContext.Session.SetInt32("UserID", user.UserID);
                // Store session or authentication logic (use Identity for real apps)
                HttpContext.Session.SetString("UserName", user.Username);

                // Redirect to Home Page
                return RedirectToAction("Index", "Home");
            }
            else
            {
                // Show error message on login page
                ViewBag.ErrorMessage = "Invalid Username or Password";
                return View();
            }
        }
    }
}
