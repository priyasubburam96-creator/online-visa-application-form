﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using Online_VisApp.Data;
using Online_VisApp.ViewModels;
using System.Data;

namespace Online_VisApp.Controllers
{
    public class EvisaApplicationController : Controller
    {
        private readonly ApplicationDbContext _context;
        public EvisaApplicationController(ApplicationDbContext context)
        {
            _context = context;
        }
        [HttpGet]
        public async Task<IActionResult> Index()
        {
            var model = new VisaApplicationViewModel
            {
                VisaCountries = await _context.CountryMasters
                    .Select(c => new SelectListItem { Value = c.CountryID.ToString(), Text = c.CountryName })
                    .ToListAsync(),

                VisaTypes = await _context.VisaTypeMasters
                    .Select(v => new SelectListItem { Value = v.VisaTypeID.ToString(), Text = v.VisaTypeName })
                    .ToListAsync(),

                VisaDurations = await _context.VisaDurationMasters
                    .Select(v => new SelectListItem { Value = v.VisaDurationID.ToString(), Text = v.VisaDuration })
                    .ToListAsync(),
                CountryOfOrigins = await _context.CountryMasters
                .Select(c => new SelectListItem { Value = c.CountryID.ToString(), Text = c.CountryName })
                .ToListAsync()

            };

            return View(model);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Index(VisaApplicationViewModel model)
        {

            try
            {
                int ApplicationId = 0;
                // Read file data as byte arrays
                var photoData = await GetFileBytesAsync(model.PassportPhoto);
                var passportFrontPageData = await GetFileBytesAsync(model.PassportFrontPage);
                var passportLastPageData = await GetFileBytesAsync(model.PassportLastPage);
                var policeClearanceData = await GetFileBytesAsync(model.PoliceClearance);

                // Execute Stored Procedure using ExecuteSqlRawAsync
                await _context.Database.ExecuteSqlRawAsync(
                    "EXEC InsertVisaInfo @ApplicationId, @VisaCountryID, @VisaTypeID, @VisaDurationID, @name, @phoneno, @emailid, @dob, @gender, @maritalstatus, @fathername, @mothername, @streetaddr, @city, @state, @countryID, @zipcode, @UserID, " +
                    "@passportno, @placeofissue, @passdateofissue, @passportexpirydate, @travelfromdate, @traveltodate, @travelcomments, " +
                    "@passportfrontdocumentID, @photodocumentID, @photodocumentext, @photodocumentbyte, @passportfrontdocumentbyte, @passportfrontdocumentext, " +
                    "@passportbackdocumentID, @passportbackdocumentbyte, @passportbackdocumentext, @policeclearancedocumentID, @policeclearancedocumentbyte, @policeclearancedocumentext",

                    // Integer Parameters
                    new SqlParameter("@ApplicationId", SqlDbType.Int) { Value = ApplicationId },
                    new SqlParameter("@VisaCountryID", SqlDbType.Int) { Value = Convert.ToInt32(model.VisaCountry) },
                    new SqlParameter("@VisaTypeID", SqlDbType.Int) { Value = Convert.ToInt32(model.VisaType) },
                    new SqlParameter("@VisaDurationID", SqlDbType.Int) { Value = Convert.ToInt32(model.VisaDuration) },
                    new SqlParameter("@countryID", SqlDbType.Int) { Value = Convert.ToInt32(model.CountryOfOrigin) },

                    // String Parameters (Varchar/NVarchar)
                    new SqlParameter("@name", model.Name ?? (object)DBNull.Value),
                    new SqlParameter("@phoneno", model.PhoneNumber ?? (object)DBNull.Value),
                    new SqlParameter("@emailid", model.EmailId ?? (object)DBNull.Value),
                   new SqlParameter("@dob", model.DateOfBirth != default(DateTime) ? model.DateOfBirth : (object)DBNull.Value),
                    new SqlParameter("@gender", model.Gender ?? (object)DBNull.Value),
                    new SqlParameter("@maritalstatus", model.MaritalStatus ?? (object)DBNull.Value),
                    new SqlParameter("@fathername", model.FatherName ?? (object)DBNull.Value),
                    new SqlParameter("@mothername", model.MotherName ?? (object)DBNull.Value),
                    new SqlParameter("@streetaddr", model.StreetAddress ?? (object)DBNull.Value),
                    new SqlParameter("@city", model.City ?? (object)DBNull.Value),
                    new SqlParameter("@state", model.State ?? (object)DBNull.Value),
                    new SqlParameter("@zipcode", model.ZipCode ?? (object)DBNull.Value),
                    new SqlParameter("@UserID", HttpContext.Session.GetInt32("UserID") ?? (object)DBNull.Value),

                    // Passport Details
                    new SqlParameter("@passportno", model.PassportNumber ?? (object)DBNull.Value),
                    new SqlParameter("@placeofissue", model.PlaceOfIssue ?? (object)DBNull.Value),
                    new SqlParameter("@passdateofissue", model.DateOfIssue != default(DateTime) ? model.DateOfIssue : (object)DBNull.Value),
                   new SqlParameter("@passportexpirydate", model.PassportExpiryDate != default(DateTime) ? model.PassportExpiryDate : (object)DBNull.Value),
                    // Travel Details
                    new SqlParameter("@travelfromdate", model.TravelFromDate != default(DateTime) ? model.TravelFromDate : (object)DBNull.Value),
                    new SqlParameter("@traveltodate", model.TravelToDate != default(DateTime) ? model.TravelToDate : (object)DBNull.Value),
                    new SqlParameter("@travelcomments", model.TravelComments ?? (object)DBNull.Value),

                    // Document Details
                    new SqlParameter("@photodocumentID", SqlDbType.Int) { Value = 1 },
                    new SqlParameter("@photodocumentext", "jpg"),  // Assuming JPEG format, change if necessary
                    new SqlParameter("@photodocumentbyte", SqlDbType.VarBinary) { Value = (photoData ?? (object)DBNull.Value) },

                    new SqlParameter("@passportfrontdocumentID", SqlDbType.Int) { Value = 2 },
                    new SqlParameter("@passportfrontdocumentext", "jpg"),
                    new SqlParameter("@passportfrontdocumentbyte", SqlDbType.VarBinary) { Value = (passportFrontPageData ?? (object)DBNull.Value) },

                    new SqlParameter("@passportbackdocumentID", SqlDbType.Int) { Value = 3 },
                    new SqlParameter("@passportbackdocumentext", "jpg"),
                    new SqlParameter("@passportbackdocumentbyte", SqlDbType.VarBinary) { Value = (passportLastPageData ?? (object)DBNull.Value) },

                    new SqlParameter("@policeclearancedocumentID", SqlDbType.Int) { Value = 4 },
                    new SqlParameter("@policeclearancedocumentext", "pdf"),
                    new SqlParameter("@policeclearancedocumentbyte", SqlDbType.VarBinary) { Value = (policeClearanceData ?? (object)DBNull.Value) }
                ); ;

                TempData["SuccessMessage"] = "Application submitted successfully!";
                return RedirectToAction("Confirmation");
            }
            catch (Exception ex)
            {
                ModelState.AddModelError("", "An error occurred: " + ex.Message);
                await PopulateDropdowns(model);
                return View(model);
            }

        }

        public IActionResult Confirmation()
        {
            return RedirectToAction("Index", "Dashboard");
        }

        // Helper: Read file bytes
        private async Task<byte[]> GetFileBytesAsync(IFormFile file)
        {
            if (file != null && file.Length > 0)
            {
                using (var memoryStream = new MemoryStream())
                {
                    await file.CopyToAsync(memoryStream);
                    return memoryStream.ToArray();
                }
            }
            return null;
        }

        // Helper: Populate dropdown lists
        private async Task PopulateDropdowns(VisaApplicationViewModel model)
        {
            model.VisaCountries = await _context.CountryMasters
                .Select(c => new SelectListItem { Value = c.CountryID.ToString(), Text = c.CountryName })
                .ToListAsync();
            model.CountryOfOrigins = await _context.CountryMasters
                .Select(c => new SelectListItem { Value = c.CountryID.ToString(), Text = c.CountryName })
                .ToListAsync();

            model.VisaTypes = await _context.VisaTypeMasters
                .Select(v => new SelectListItem { Value = v.VisaTypeID.ToString(), Text = v.VisaTypeName })
                .ToListAsync();

            model.VisaDurations = await _context.VisaDurationMasters
                .Select(v => new SelectListItem { Value = v.VisaDurationID.ToString(), Text = v.VisaDuration })
                .ToListAsync();
        }
    }
}
