﻿using Online_VisApp.Data;
using Online_VisApp.ViewModels;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace Online_VisApp.Controllers
{
    public class DashboardController : Controller
    {
        private readonly ApplicationDbContext _context;
        public DashboardController(ApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<IActionResult> Index()
        {
            // Get logged-in user's username from session
            var username = HttpContext.Session.GetString("Username");

            // Fetch visa applications for this user
            var applications = await _context.Application_GeneralDetails
      .Where(a => a.Applicantid == HttpContext.Session.GetInt32("UserID")) // Assuming ApplicationID is your user identifier
      .Include(a => a.VisaTypeNavigation)  // Include the VisaTypeMaster navigation property
      .Include(a => a.StatusMasterNavigation)    // Include the StatusMaster navigation property
      .Include(a => a.ApplicationDocumentDetails) // Include DocumentDetails collection to access passport photo
      .Select(a => new DashboardViewModel
      {
          ApplicationId = a.ApplicationID,
          FirstName = a.FirstName,
          PhoneNo = a.Phoneno,
          EmailID = a.EmailID,

          // Safely access VisaTypeMaster navigation property to get VisaTypeName
          VisaTypeName = a.VisaTypeNavigation != null ? a.VisaTypeNavigation.VisaTypeName : null,

          // Safely access StatusMaster navigation property to get StatusName
          StatusName = a.StatusMasterNavigation != null ? a.StatusMasterNavigation.StatusName : null,

          // Get the first passport photo from the DocumentDetails collection, if available
          PassportPhotoBase64 = a.ApplicationDocumentDetails
                                 .Where(d => d.DocumentID == 1) // Filter by DocumentID = 1 (passport photo)
                                 .Select(d => d.Documenet) // Select the document byte array
                                 .FirstOrDefault() != null
                                 ? Convert.ToBase64String(a.ApplicationDocumentDetails
                                                          .Where(d => d.DocumentID == 1) // Filter by DocumentID = 1
                                                          .Select(d => d.Documenet) // Select the document byte array
                                                          .FirstOrDefault())
                                 : null // Return null if no passport photo is found
      })
      .ToListAsync();




            return View(applications);
        }
    }
}
