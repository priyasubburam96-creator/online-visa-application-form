﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Online_VisApp.Data;
using Online_VisApp.ViewModels;
using System.Net;
using System.Net.Mail;

namespace Online_VisApp.Controllers
{
    public class AdminLoginController : Controller
    {
        private readonly ApplicationDbContext _context;
        public AdminLoginController(ApplicationDbContext context)
        {
            _context = context;
        }
        public IActionResult Index()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Index(string Username, string Password)
        {
            if (Username == "admin" && Password == "admin")
            {
                return RedirectToAction("AdminDashboard", "AdminLogin");
            }
            else
            {
                // Show error message on login page
                ViewBag.ErrorMessage = "Invalid Username or Password";
                return View();
            }
        }

        [HttpGet]
        public async Task<IActionResult> ApproveApplication(int applicationid)
        {

            int applicationIdValue = applicationid; // Get the integer value from JsonElement

            // Fetch the application along with StatusMaster details
            try
            {
                var application = await _context.Application_GeneralDetails
    .Where(a => a.ApplicationID == applicationIdValue).FirstOrDefaultAsync();

                ;  // Fetch the first matching result asynchronously
                   // Find the StatusID for "Approved"
                if (application == null)
                {
                    return NotFound("Application not found or already approved.");
                }
                var approvedStatus = _context.StatusMasters.FirstOrDefault(s => s.StatusName == "Approved");

                if (approvedStatus == null)
                {
                    return NotFound("Approved status not found in StatusMaster.");
                }

                // Update the StatusID in Application_GeneralDetails
                application.VisaStatus = approvedStatus.StatusID;
                _context.SaveChanges(); // Save changes to the database

                SendEmail(application.EmailID, applicationIdValue);
                return Ok(new { message = "Application approved successfully!" });

            }
            catch (Exception ex)
            {
                string exce = ex.ToString();
                return Ok(new { message = "Application Not approved successfully!" });
            }





        }

        public async Task<IActionResult> AdminDashboard()
        {
            // Get logged-in user's username from session
            var username = HttpContext.Session.GetString("Username");

            // Fetch visa applications for this user
            var applications = await _context.Application_GeneralDetails
      .Include(a => a.VisaTypeNavigation)  // Include the VisaTypeMaster navigation property
      .Include(a => a.StatusMasterNavigation)    // Include the StatusMaster navigation property
      .Include(a => a.ApplicationDocumentDetails) // Include DocumentDetails collection to access passport photo
      .Select(a => new DashboardViewModel
      {
          ApplicationId = a.ApplicationID,
          FirstName = a.FirstName,
          PhoneNo = a.Phoneno,
          EmailID = a.EmailID,

          // Safely access VisaTypeMaster navigation property to get VisaTypeName
          VisaTypeName = a.VisaTypeNavigation != null ? a.VisaTypeNavigation.VisaTypeName : null,

          // Safely access StatusMaster navigation property to get StatusName
          StatusName = a.StatusMasterNavigation != null ? a.StatusMasterNavigation.StatusName : null,

          // Get the first passport photo from the DocumentDetails collection, if available
          PassportPhotoBase64 = a.ApplicationDocumentDetails
                                 .Where(d => d.DocumentID == 1) // Filter by DocumentID = 1 (passport photo)
                                 .Select(d => d.Documenet) // Select the document byte array
                                 .FirstOrDefault() != null
                                 ? Convert.ToBase64String(a.ApplicationDocumentDetails
                                                          .Where(d => d.DocumentID == 1) // Filter by DocumentID = 1
                                                          .Select(d => d.Documenet) // Select the document byte array
                                                          .FirstOrDefault())
                                 : null // Return null if no passport photo is found
      })
      .ToListAsync();




            return View(applications);
        }
        private void SendEmail(string email, int applicationId)
        {
            // Configure the SMTP client
            SmtpClient smtpClient = new SmtpClient("smtp.gmail.com"); // Gmail SMTP server address
            smtpClient.Port = 587; // Gmail SMTP port
            smtpClient.UseDefaultCredentials = false;
            smtpClient.Credentials = new NetworkCredential("testeswatini123@gmail.com", "nhmvpsltjawiegba"); // Gmail credentials
            smtpClient.EnableSsl = true;

            // Create the email message
            MailMessage mailMessage = new MailMessage();
            mailMessage.From = new MailAddress("nvr.reach@gmail.com"); // Replace with your email address
            mailMessage.To.Add(email); // Add the recipient's email address
            mailMessage.Subject = "Visa Approved";
            mailMessage.Body = "Your visa has been Approved Application Id is  VST000" + applicationId;

            // Send the email
            try
            {
                // Attempt to send the email
                smtpClient.Send(mailMessage);
                // Email sent successfully
            }
            catch (SmtpException ex)
            {

            }
        }
    }
}
