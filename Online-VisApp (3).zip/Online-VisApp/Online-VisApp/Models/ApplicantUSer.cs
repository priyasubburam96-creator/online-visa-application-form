﻿using System.ComponentModel.DataAnnotations;

namespace Online_VisApp.Models
{
    public class ApplicantUSer
    {
        [Key]
        public int UserID { get; set; }

        [Required]
        public string Name { get; set; }

        [Required]
        public string EmailID { get; set; }
        [Required]
        public string Phoneno { get; set; }
        [Required]
        public string Username { get; set; }
        [Required]
        public string Password { get; set; }
        [Required]
        public string Question1 { get; set; }
        [Required]
        public string Answer1 { get; set; }

    }
}
