﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Online_VisApp.Models
{
    [Table("Application_GeneralDetails")]
    public class ApplicationGeneralDetails
    {
        [Key]
        public int ApplicationID { get; set; }  // Primary Key
        public string? FirstName { get; set; }
        public string? LastName { get; set; }
        public string? DOB { get; set; }
        public int? CountryofOrigin { get; set; }
        public string? Gender { get; set; }
        public string? MaritalStatus { get; set; }
        public string? Occupation { get; set; }
        public string? Phoneno { get; set; }
        public string? EmailID { get; set; }
        public string? Address { get; set; }
        public string? City { get; set; }
        public string? State { get; set; }
        public string? ZipCode { get; set; }
        public int? CountryID { get; set; }
        public int? VisaTypeID { get; set; }
        public int? VisaDurationID { get; set; }
        public int? VisaCountry { get; set; }
        public int? Applicantid { get; set; }
        public int? VisaStatus { get; set; }
        public string? FatherName { get; set; }
        public string? MotherName { get; set; }

        [ForeignKey("VisaTypeID")]
        public virtual VisaTypeMaster VisaTypeNavigation { get; set; } // Navigation property for VisaTypeMaster
        [ForeignKey("VisaStatus")]
        public virtual StatusMaster StatusMasterNavigation { get; set; } // Navigation property for StatusMaster

        // Navigation properties (for related tables)
        public ICollection<ApplicationPassportDetails> PassportDetails { get; set; }
        public ICollection<ApplicationTravelDetails> TravelDetails { get; set; }
        [InverseProperty("Application")]
        public virtual ICollection<ApplicationDocumentDetails> ApplicationDocumentDetails { get; } = new List<ApplicationDocumentDetails>();


    }
}
