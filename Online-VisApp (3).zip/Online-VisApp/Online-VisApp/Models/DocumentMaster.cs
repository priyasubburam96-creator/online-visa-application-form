﻿namespace Online_VisApp.Models
{
    public class DocumentMaster
    {
        public int DocumentID { get; set; }
        public string DocumentName { get; set; }
    }
}
