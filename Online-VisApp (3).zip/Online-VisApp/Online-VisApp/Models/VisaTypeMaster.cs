﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Online_VisApp.Models
{
    public class VisaTypeMaster
    {
        [Key]
        public int VisaTypeID { get; set; }
        public string VisaTypeName { get; set; }
        [InverseProperty("VisaTypeNavigation")]
        public virtual ICollection<ApplicationGeneralDetails> ApplicationGeneralDetails { get; } = new List<ApplicationGeneralDetails>();

    }
}
