﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Online_VisApp.Models
{
    [Table("Application_PassportDetails")]
    public class ApplicationPassportDetails
    {
        [Key]
        public int ApplicationPassportID { get; set; }  // Primary Key
        public int ApplicationID { get; set; }  // Foreign Key to ApplicationGeneralDetails
        public string PassportNo { get; set; }
        public string Issuedat { get; set; }
        public DateTime IssuedOn { get; set; }
        public DateTime Expirydate { get; set; }

        // Navigation property
        public ApplicationGeneralDetails ApplicationGeneralDetails { get; set; }
    }
}
