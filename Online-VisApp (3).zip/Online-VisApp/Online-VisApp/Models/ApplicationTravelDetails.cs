﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Online_VisApp.Models
{
    [Table("Application_TravelDetails")]
    public class ApplicationTravelDetails
    {
        [Key]
        public int ApplicationTravelID { get; set; }  // Primary Key
        public int ApplicationID { get; set; }  // Foreign Key to ApplicationGeneralDetails
        public string DateOfArrival { get; set; }
        public string TravelToDate { get; set; }
        public string Comments { get; set; }

        // Navigation property
        public ApplicationGeneralDetails ApplicationGeneralDetails { get; set; }
    }
}
