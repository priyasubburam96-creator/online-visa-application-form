﻿namespace Online_VisApp.Models
{
    public class CountryMaster
    {
        public int CountryID { get; set; }
        public string CountryType { get; set; }
        public string CountryName { get; set; }
    }
}
