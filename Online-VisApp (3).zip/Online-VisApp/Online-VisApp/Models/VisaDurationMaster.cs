﻿namespace Online_VisApp.Models
{
    public class VisaDurationMaster
    {
        public int VisaDurationID { get; set; }
        public string VisaDuration { get; set; }
    }
}
