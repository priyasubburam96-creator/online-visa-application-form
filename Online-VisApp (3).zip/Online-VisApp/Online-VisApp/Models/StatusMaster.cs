﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Online_VisApp.Models
{
    public class StatusMaster
    {
        [Key]
        public int StatusID { get; set; }
        public string StatusCode { get; set; }
        public string StatusName { get; set; }
        [InverseProperty("StatusMasterNavigation")]
        public virtual ICollection<ApplicationGeneralDetails> ApplicationGeneralDetails { get; } = new List<ApplicationGeneralDetails>();

    }
}
