﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Online_VisApp.Models
{
    [Table("Application_DocumentDetails")]
    public class ApplicationDocumentDetails
    {
        [Key]
        public int ApplicationDocumentID { get; set; }  // Primary Key
        public int ApplicationID { get; set; }  // Foreign Key to ApplicationGeneralDetails
        public string DocumentType { get; set; }
        public int? DocumentID { get; set; }
        public byte[] Documenet { get; set; }  // For storing document as binary

        [ForeignKey("ApplicationId")]
        [InverseProperty("ApplicationDocumentDetails")]
        public virtual ApplicationGeneralDetails Application { get; set; } = null!;
    }
}
