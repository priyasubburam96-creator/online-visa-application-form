﻿using Microsoft.EntityFrameworkCore;
using Online_VisApp.Models;

namespace Online_VisApp.Data
{
    public class ApplicationDbContext:DbContext
    {
        public ApplicationDbContext(DbContextOptions options):base(options) 
        {
            
        }
        public DbSet<ApplicantUSer> ApplicantUSer { get; set; }
        public DbSet<CountryMaster> CountryMasters { get; set; }
        public DbSet<VisaTypeMaster> VisaTypeMasters { get; set; }
        public DbSet<VisaDurationMaster> VisaDurationMasters { get; set; }
        public DbSet<StatusMaster> StatusMasters { get; set; }
        public DbSet<DocumentMaster> DocumentMasters { get; set; }
        public DbSet<ApplicationGeneralDetails> Application_GeneralDetails { get; set; }
        public DbSet<ApplicationPassportDetails> Application_PassportDetails { get; set; }
        public DbSet<ApplicationTravelDetails> Application_TravelDetails { get; set; }
        public DbSet<ApplicationDocumentDetails> Application_DocumentDetails { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {

            base.OnModelCreating(modelBuilder);

            // Define Primary Keys
            modelBuilder.Entity<CountryMaster>()
                .HasKey(c => c.CountryID);

            modelBuilder.Entity<VisaTypeMaster>()
                .HasKey(v => v.VisaTypeID);  // Primary Key for VisaTypeMaster

            modelBuilder.Entity<VisaDurationMaster>()
                .HasKey(v => v.VisaDurationID);  // Primary Key for VisaDurationMaster

            modelBuilder.Entity<StatusMaster>()
                .HasKey(s => s.StatusID);

            modelBuilder.Entity<DocumentMaster>()
                .HasKey(d => d.DocumentID);  // Assuming DocumentMaster also has a primary key

            modelBuilder.Entity<CountryMaster>().ToTable("CountryMaster");
            modelBuilder.Entity<VisaTypeMaster>().ToTable("VisaTypeMaster");
            modelBuilder.Entity<VisaDurationMaster>().ToTable("VisaDurationMaster");
            modelBuilder.Entity<StatusMaster>().ToTable("StatusMaster");
            modelBuilder.Entity<DocumentMaster>().ToTable("DocumentMaster");
            // Configure VisaTypeMaster foreign key relationship
            modelBuilder.Entity<ApplicationGeneralDetails>()
                .HasOne(a => a.VisaTypeNavigation)
                .WithMany(v => v.ApplicationGeneralDetails)  // One VisaTypeMaster can have many ApplicationGeneralDetails
                .HasForeignKey(a => a.VisaTypeID)            // Foreign Key: VisaTypeID
                .HasConstraintName("FK_Application_VisaType") // Optional name of the foreign key constraint
                .OnDelete(DeleteBehavior.Restrict);          // Optional delete behavior


            // Configure StatusMaster foreign key relationship
            modelBuilder.Entity<ApplicationGeneralDetails>()
                .HasOne(a => a.StatusMasterNavigation)
               .WithMany(s => s.ApplicationGeneralDetails)                      // StatusMaster can have many ApplicationGeneralDetails
                .HasForeignKey(a => a.VisaStatus)   // Foreign key: VisaStatus
                .HasConstraintName("FK_Application_StatusMaster") // Optional name of the foreign key constraint
                .OnDelete(DeleteBehavior.Restrict); // Optional delete behavior
        }
    }
}
